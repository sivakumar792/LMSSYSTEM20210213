﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.WebControls;

public partial class Home : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("server=52.255.151.7,1433;database=Tacdev_db_olt;uid=tac_admin;pwd=De4Ki3avFINcarECkDiU");
    protected void Page_Load(object sender, EventArgs e)
    {
        //DataSet ds = new DataSet();
        //SqlDataAdapter da = new SqlDataAdapter("select * from BookMst", con);
        //da.Fill(ds);
        //Chart1.DataSource = ds;


        DataTable dt = new DataTable();
        using (SqlConnection con = new SqlConnection("server=52.255.151.7,1433;database=Tacdev_db_olt;uid=tac_admin;pwd=De4Ki3avFINcarECkDiU"))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT BookName as Name, COUNT(BookID) AS Total  FROM BookMst GROUP BY BookName", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
        }
        string[] x = new string[dt.Rows.Count];
        int[] y = new int[dt.Rows.Count];
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            x[i] = dt.Rows[i][0].ToString();
            y[i] = Convert.ToInt32(dt.Rows[i][1]);
        }

        Chart1.Series[0].Points.DataBindXY(x, y);
        Chart1.Series[0].ChartType = SeriesChartType.Pie;
        Chart1.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
        //Chart1.Legends[0].Enabled = true;




        DataTable dt1 = new DataTable();
        using (SqlConnection con = new SqlConnection("server=52.255.151.7,1433;database=Tacdev_db_olt;uid=tac_admin;pwd=De4Ki3avFINcarECkDiU"))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT StudentName as Name, COUNT(SID) AS Total  FROM StudentMst GROUP BY StudentName  ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt1);
            con.Close();
        }
        string[] xx = new string[dt1.Rows.Count];
        int[] yy = new int[dt1.Rows.Count];
        for (int i = 0; i < dt1.Rows.Count; i++)
        {
            xx[i] = dt1.Rows[i][0].ToString();
            yy[i] = Convert.ToInt32(dt1.Rows[i][1]);
        }

        Chart2.Series[0].Points.DataBindXY(xx, yy);
        Chart2.Series[0].ChartType = SeriesChartType.Pie;
        Chart2.ChartAreas["ChartArea2"].Area3DStyle.Enable3D = true;
    }
}